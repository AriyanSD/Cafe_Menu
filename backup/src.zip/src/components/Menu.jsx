import MenuItem from "./MenuItem"
export default function Menu({menuItems}){
    return(
        menuItems.map(item=><MenuItem key={item.title} title={item.title} description={item.description} img={item.img} price={item.price}/>)
    )

}