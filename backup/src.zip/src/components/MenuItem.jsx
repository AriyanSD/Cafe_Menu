export default function MenuItem({ img, title, description, price }) {
  return (
    <div className="menu-item">
      <div id="description">
        <p>{description}</p>
        <br />
        <span>{price} T</span>
      </div>

      <div id="item-image">
        <img src={img} alt="MenuItem" />
        <br />
        <h3>{title}</h3>
      </div>
    </div>
  );
}
